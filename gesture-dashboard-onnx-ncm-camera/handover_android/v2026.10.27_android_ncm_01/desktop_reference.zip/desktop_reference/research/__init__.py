"""Reproducible offline gesture experiments."""
