# Dynamic Gesture Runtime API

This is the canonical camera-to-command runtime contract for Android and iOS.
It includes the MediaPipe landmark detector and the landmarks-in gesture API.
The gesture API is exported by the Flutter package as:

```dart
import 'package:mobile_landmark_telemetry/gesture_runtime_api.dart';
```

The `flutter/` directory in the release archive is a source snapshot for the
existing `mobile_landmark_telemetry` Flutter package, not a separate standalone
package. The TFLite assets and `flutter_litert`/`crypto` dependencies remain
declared by that package.

The camera layer uses the bundled MediaPipe Full landmark model. It supplies
landmarks for zero, one, or two physical hands to the gesture runtime. The
gesture runtime owns temporal buffering, preprocessing, feature fusion, model
normalization, LiteRT inference, command confirmation, duplicate suppression,
and per-frame cross-hand arbitration.

The supplied v10.3 models are static-free. Their complete gesture vocabulary,
physical descriptions, and application semantics are defined in
`GESTURES.md`.

## Camera and landmark detector

`contracts/mediapipe_detector.json` defines the required detector
configuration:

- MediaPipe Full landmark model (`hand_landmark_full.tflite`);
- one detector invocation for up to two hands;
- 10 landmark inferences per second;
- latest-frame-only processing: replace a pending frame instead of building a
  queue;
- tracking enabled;
- MediaPipe's supplied gesture classifier disabled;
- LiteRT GPU preferred, with XNNPACK CPU fallback.

The camera preview may run faster than 10 FPS. Only landmark inference is
rate-limited. Each completed detector result is passed to `GestureRuntimeApi`
with its original capture timestamp. An integration must report the achieved
detector rate if the device cannot sustain 10 FPS; it must not silently switch
to MediaPipe Lite.

The release includes the `hand_detection` Flutter dependency, the required
MediaPipe palm and Full landmark models, `hand_detector_factory.dart`, and
`camera_frame_adapter.dart`. These are the same detector and camera-coordinate
components used by the reference mobile implementation. MediaPipe Lite, W8A8,
and canned-gesture model assets are not part of this handover.

Place the included `third_party/hand_detection` directory under the consuming
Flutter application and declare it in that application's `pubspec.yaml`:

```yaml
dependencies:
  hand_detection:
    path: third_party/hand_detection
```

The consuming application also needs its normal camera package. Camera frames
must be converted with `camera_frame_adapter.dart`, processed by the detector
created through `hand_detector_factory.dart`, and then submitted to
`GestureRuntimeApi` using the normalized landmark contract below.

## Minimal use

```dart
final engine = GestureRuntimeApi(
  model: MobileGestureModel.v10_3Current8Step,
  onCommand: (event) {
    sendMotorCommand(event.command);
  },
);
await engine.initialize();

engine.processFrame(GestureApiFrame(
  timestampMs: monotonicTimestampMs,
  frameWidth: imageWidth.toDouble(),
  frameHeight: imageHeight.toDouble(),
  hands: <GestureApiHand>[
    GestureApiHand(
      hand: GesturePhysicalHand.right,
      normalizedLandmarks: rightHandLandmarks,
    ),
  ],
));
```

Call `processFrame` once for every landmark result, including frames containing
no hands. Call `reset` after a camera restart, timestamp reset, orientation
change, or landmark-pipeline restart. Call `close` when the runtime is no longer
needed.

## Required input contract

- Timestamp: finite monotonic milliseconds within one runtime session.
- Frame: the upright, unmirrored image coordinate system used for landmarks.
- Hand identity: physical `left` or `right`, not screen position.
- Landmark order: canonical MediaPipe indices `0..20`.
- `x`: normalized by upright frame width.
- `y`: normalized by upright frame height.
- `z`: normalized by upright frame width.
- Missing hand: omit that hand from `hands`; never repeat stale landmarks.
- Maximum: one physical left and one physical right hand per frame.

See `contracts/gesture_frame.schema.json` and
`contracts/gesture_command.schema.json` for the wire representation.

## Runtime behavior

`contracts/established_live_runtime.json` is the normative runtime
configuration:

- 900 ms maximum rolling history;
- 500 ms minimum history;
- minimum 4 valid landmark frames;
- no percentage coverage gate;
- checkpoint-defined action focus and step count;
- canonical 76 features followed by validity-guarded 139-feature fusion;
- checkpoint mean/std normalization;
- 0.80 class-confidence threshold;
- strong dynamic shortcut at 0.92 confidence and 0.25 margin;
- otherwise 2 matching predictions in the latest 3;
- 350 ms hand-loss reset;
- no timed command cooldown;
- repeated identical dynamic commands require confirmed `NO_GESTURE` first;
- if both hand windows emit on the same source timestamp, the first completed
  inference is the only command returned.

Follow-lock sequencing is optional and disabled by default. If enabled,
`FOLLOW_UNLOCK` is accepted only after `FOLLOW_LOCK`, and all other gestures
are suppressed while follow lock is active.

## Directional return-motion limitation

The classifier observes hand motion; it cannot infer whether that motion is a
new command or merely the user's return to the starting position. For example,
the return path after `MOVE_LEFT` has the same direction as an intentional
`MOVE_RIGHT`. The same ambiguity applies to `MOVE_RIGHT`/`MOVE_LEFT` and
`MOVE_UP`/`MOVE_DOWN`.

This is not a left/right-hand mapping issue, and integrations must not swap
labels or mirror coordinates to compensate for it. The current runtime blocks
an immediate repeat of the same dynamic command until `NO_GESTURE` is
confirmed, but it does not suppress the opposite label because that could also
be a deliberate command. Therefore, the product interaction must define how a
completed directional gesture is reset—for example, by returning outside the
active gesture region, pausing in a neutral pose, or applying a product-level
motion state. Landmarks alone cannot reliably distinguish these intentions.

## Model formats

The release contains ONNX FP32 and TFLite INT8 artifacts for both supported
temporal resolutions:

- `models/v10_3_8_step/`
- `models/v10_3_16_step/`

Both resolutions are intentional deployment options. The consuming
application selects one complete model configuration; it must not mix an
8-step model with a 16-step manifest or preprocessing shape.

Use the TFLite artifact with the Flutter reference implementation. Native
integrations may use either artifact, provided they implement the same tensor,
normalization, preprocessing, and output-decoding contracts. Format-specific
tensor details and conversion checks are recorded in each
`conversion_manifest.json`.

## Platform boundary

The reference implementation runs on Android and iOS when embedded in Flutter.
A native Kotlin or Swift application must either embed this Flutter module or
implement this exact contract and pass the shared parity fixtures before it can
be declared equivalent. Landmark producers must adapt their output to the input
contract; preprocessing behavior is not inferred from undocumented landmark
formats.

Validation scope and platform qualification are documented separately in
`VALIDATION.md`.
