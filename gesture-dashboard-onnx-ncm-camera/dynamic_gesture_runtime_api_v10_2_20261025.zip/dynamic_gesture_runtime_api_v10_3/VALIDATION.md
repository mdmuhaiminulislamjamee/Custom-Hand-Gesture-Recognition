# Dynamic Gesture Runtime Validation

## Completed

- Flutter static analysis.
- Android debug build.
- Public input and output contract tests.
- Command-controller behavior tests.
- Python-to-Dart preprocessing parity on a real recording for 8-step and
  16-step inputs.
- ONNX and TFLite conversion validation recorded in each conversion manifest.

## Not completed

- iOS compilation and device execution. The reference implementation was
  prepared on Linux, where Xcode and an iOS device runtime are unavailable.
  The consuming app team must compile the Flutter integration with Xcode and
  verify it on its target iPhone hardware.
- Native Kotlin implementation qualification.
- Native Swift implementation qualification.

Native implementations are considered compatible only after passing the shared
preprocessing fixture and command-controller tests.
