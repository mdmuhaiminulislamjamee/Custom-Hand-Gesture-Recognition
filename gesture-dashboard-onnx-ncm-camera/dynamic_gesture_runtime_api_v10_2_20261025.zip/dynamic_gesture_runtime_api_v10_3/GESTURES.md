# Gesture Vocabulary and Application Semantics

## Static-free scope

The supplied v10.3 models are **static-free**. They expose nine dynamic
gesture commands plus `NO_GESTURE`:

- `MOVE_LEFT`
- `MOVE_RIGHT`
- `MOVE_UP`
- `MOVE_DOWN`
- `ZOOM_IN`
- `ZOOM_OUT`
- `INDEX_CIRCLE`
- `FOLLOW_LOCK`
- `FOLLOW_UNLOCK`
- `NO_GESTURE` (internal non-command result)

Static gestures such as `FIST`, `OK`, `PHONE_POSE`, `THUMBS_UP`, and
`VICTORY` are not output classes. During this static-free experiment they are
treated as `NO_GESTURE`; an integration must not expect static commands from
these models.

## Commands

| Output | Physical gesture represented by the training data | Runtime meaning |
|---|---|---|
| `MOVE_LEFT` | Perform the approved directional hand/finger motion toward the left. | Emit one left-movement command. Exact motor or UI mapping belongs to the consuming application. |
| `MOVE_RIGHT` | Perform the approved directional hand/finger motion toward the right. | Emit one right-movement command. Exact motor or UI mapping belongs to the consuming application. |
| `MOVE_UP` | Perform the approved directional hand/finger motion upward. | Emit one upward-movement command. Exact motor or UI mapping belongs to the consuming application. |
| `MOVE_DOWN` | Perform the approved directional hand/finger motion downward. | Emit one downward-movement command. Exact motor or UI mapping belongs to the consuming application. |
| `ZOOM_IN` | Begin with the thumb and index fingertips touching, with both fingers extended, then separate them. The amount moved by each finger varies between users. | Emit one zoom-in command. |
| `ZOOM_OUT` | Perform the closing pinch motion: move the extended thumb and index fingertips toward one another. | Emit one zoom-out command. |
| `INDEX_CIRCLE` | Trace a small circle with the index finger. | Emit one index-circle command. Its product action is not fixed by the runtime and must be assigned by the consuming application. |
| `FOLLOW_LOCK` | Palm faces the camera and the open hand dynamically closes, including the thumb. | Emit a follow-lock event. If optional follow sequencing is enabled, enter the locked follow state and suppress ordinary gesture commands. |
| `FOLLOW_UNLOCK` | Perform the corresponding opening/release motion. | Emit a follow-unlock event. If optional follow sequencing is enabled, it is accepted only while follow lock is active and then exits the locked state. |
| `NO_GESTURE` | Background motion, explicit non-command motion, hard negatives, and static gestures excluded from this experiment's command vocabulary. | Emit no application command. Confirmed `NO_GESTURE` rearms duplicate suppression. |

## Integration boundaries

- The model reports recognized gesture classes; it does not decide motor
  distance, motor speed, screen displacement, zoom factor, or application
  navigation.
- `FOLLOW_LOCK` and `FOLLOW_UNLOCK` are ordinary model outputs by default.
  Stateful follow sequencing is an optional runtime mode and is disabled by
  default.
- A command event is discrete. Continuous device motion, if required, must be
  implemented and stopped by the consuming application.
- Left/right hand identity does not change the meaning of a command. Both
  physical hands use the same command vocabulary.
- Opposite-direction return motion remains ambiguous as described in the main
  README. The model cannot infer user intent from two physically identical
  trajectories.
