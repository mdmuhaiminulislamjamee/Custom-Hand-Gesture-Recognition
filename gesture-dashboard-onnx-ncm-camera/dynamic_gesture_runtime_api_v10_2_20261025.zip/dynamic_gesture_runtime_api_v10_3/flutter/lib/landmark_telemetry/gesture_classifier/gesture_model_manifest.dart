import 'dart:convert';

class GestureTensorContract {
  const GestureTensorContract({
    required this.position,
    required this.semanticName,
    required this.shape,
    required this.scale,
    required this.zeroPoint,
  });

  final int position;
  final String semanticName;
  final List<int> shape;
  final double scale;
  final int zeroPoint;

  factory GestureTensorContract.fromJson(Map<String, dynamic> json) {
    if (json['dtype'] != 'int8') {
      throw const FormatException('Gesture tensor must use INT8 I/O.');
    }
    return GestureTensorContract(
      position: (json['io_position'] as num).toInt(),
      semanticName: json['semantic_name'] as String,
      shape: (json['shape'] as List<dynamic>)
          .map((value) => (value as num).toInt())
          .toList(growable: false),
      scale: (json['quantization_scale'] as num).toDouble(),
      zeroPoint: (json['quantization_zero_point'] as num).toInt(),
    );
  }
}

class GestureModelManifest {
  const GestureModelManifest({
    required this.schemaVersion,
    required this.modelName,
    required this.modelSha256,
    required this.modelBytes,
    required this.labels,
    required this.formLabels,
    required this.completionLabels,
    required this.featureMean,
    required this.featureStd,
    required this.input,
    required this.outputs,
    required this.preprocessingConfig,
  });

  final int schemaVersion;
  final String modelName;
  final String modelSha256;
  final int modelBytes;
  final List<String> labels;
  final List<String> formLabels;
  final List<String> completionLabels;
  final List<double> featureMean;
  final List<double> featureStd;
  final GestureTensorContract input;
  final Map<String, GestureTensorContract> outputs;
  final Map<String, dynamic> preprocessingConfig;

  int get steps => input.shape[1];
  bool get focusAction => preprocessingConfig['focus_action'] != false;
  bool get focusActionForAll =>
      preprocessingConfig['focus_action_for_all'] == true;

  factory GestureModelManifest.decode(String source) {
    final root = jsonDecode(source) as Map<String, dynamic>;
    final normalization = root['normalization'] as Map<String, dynamic>;
    final tensorContract =
        root['tflite_tensor_contract'] as Map<String, dynamic>;
    final artifacts = root['artifacts'] as Map<String, dynamic>;
    final tfliteArtifact = artifacts['tflite_int8'] as Map<String, dynamic>;
    final outputList = (tensorContract['outputs'] as List<dynamic>)
        .map(
          (value) =>
              GestureTensorContract.fromJson(value as Map<String, dynamic>),
        )
        .toList(growable: false);
    final outputs = <String, GestureTensorContract>{
      for (final output in outputList) output.semanticName: output,
    };
    final manifest = GestureModelManifest(
      schemaVersion: (root['schema_version'] as num).toInt(),
      modelName: root['model_name'] as String,
      modelSha256: tfliteArtifact['sha256'] as String,
      modelBytes: (tfliteArtifact['bytes'] as num).toInt(),
      labels: _strings(root['labels']),
      formLabels: _strings(root['form_labels']),
      completionLabels: _strings(root['completion_labels']),
      featureMean: _doubles(normalization['mean']),
      featureStd: _doubles(normalization['std']),
      input: GestureTensorContract.fromJson(
        tensorContract['input'] as Map<String, dynamic>,
      ),
      outputs: outputs,
      preprocessingConfig:
          (root['preprocessing_config'] as Map<String, dynamic>?) ??
          const <String, dynamic>{},
    );
    manifest.validate();
    return manifest;
  }

  void validate() {
    if (schemaVersion != 3 || modelName != 'FingerMotionFusionTCNClassifier') {
      throw FormatException(
        'Unsupported gesture model manifest: schema $schemaVersion, '
        'model $modelName.',
      );
    }
    if (input.shape.length != 3 ||
        input.shape[0] != 1 ||
        !const <int>{8, 16}.contains(input.shape[1]) ||
        input.shape[2] != 139) {
      throw FormatException('Expected input shape [1, 8|16, 139].');
    }
    if (featureMean.length != 139 || featureStd.length != 139) {
      throw const FormatException('Expected 139 normalization values.');
    }
    if (featureStd.any((value) => value <= 0 || !value.isFinite)) {
      throw const FormatException('Normalization std must be finite and > 0.');
    }
    if ((labels.length != 10 && labels.length != 15) ||
        labels.first != 'NO_GESTURE' ||
        formLabels.length != 3 ||
        completionLabels.length != 2) {
      throw const FormatException(
        'Gesture label counts do not match the model.',
      );
    }
    final expectedOutputs = <String, List<int>>{
      'form_logits': <int>[1, 3],
      'completion_logits': <int>[1, 2],
      'class_logits': <int>[1, labels.length],
    };
    for (final entry in expectedOutputs.entries) {
      final output = outputs[entry.key];
      if (output == null || !_sameShape(output.shape, entry.value)) {
        throw FormatException('Invalid ${entry.key} tensor contract.');
      }
    }
  }

  static List<String> _strings(Object? values) => (values as List<dynamic>)
      .map((value) => value as String)
      .toList(growable: false);

  static List<double> _doubles(Object? values) => (values as List<dynamic>)
      .map((value) => (value as num).toDouble())
      .toList(growable: false);

  static bool _sameShape(List<int> left, List<int> right) {
    if (left.length != right.length) return false;
    for (var index = 0; index < left.length; index++) {
      if (left[index] != right[index]) return false;
    }
    return true;
  }
}
