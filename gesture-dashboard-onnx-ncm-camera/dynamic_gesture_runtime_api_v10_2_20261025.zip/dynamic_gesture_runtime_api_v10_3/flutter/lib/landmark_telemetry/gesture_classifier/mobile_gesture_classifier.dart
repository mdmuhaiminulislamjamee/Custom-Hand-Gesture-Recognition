import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter/services.dart';
import 'package:flutter_litert/native.dart';

import 'gesture_control.dart';
import 'gesture_model_manifest.dart';
import 'gesture_preprocessor.dart';

enum MobileGestureModel {
  v10_3Current8Step(
    id: 'v10.3 current 8-step · 9218007110c6',
    modelAsset: 'assets/models/v10_3_9218007110c6_8_step_int8.tflite',
    manifestAsset: 'assets/models/v10_3_9218007110c6_8_step_manifest.json',
  ),
  v10_3Current16Step(
    id: 'v10.3 current 16-step · 89d243e075de',
    modelAsset: 'assets/models/v10_3_89d243e075de_16_step_int8.tflite',
    manifestAsset: 'assets/models/v10_3_89d243e075de_16_step_manifest.json',
  ),
  v10_2Current8Step(
    id: 'v10.2 current 8-step · fefa25120ddf',
    modelAsset: 'assets/models/v10_2_fefa25120ddf_8_step_int8.tflite',
    manifestAsset: 'assets/models/v10_2_fefa25120ddf_8_step_manifest.json',
  ),
  v10_2Current16Step(
    id: 'v10.2 current 16-step · 582b588dff42',
    modelAsset: 'assets/models/v10_2_582b588dff42_16_step_int8.tflite',
    manifestAsset: 'assets/models/v10_2_582b588dff42_16_step_manifest.json',
  ),
  v10_2Previous8Step(
    id: 'v10.2 previous 8-step · 6904a089f23c',
    modelAsset: 'assets/models/v10_2_6904a089f23c_8_step_int8.tflite',
    manifestAsset: 'assets/models/v10_2_6904a089f23c_8_step_manifest.json',
  );

  const MobileGestureModel({
    required this.id,
    required this.modelAsset,
    required this.manifestAsset,
  });

  final String id;
  final String modelAsset;
  final String manifestAsset;

  String get label => id;

  static MobileGestureModel fromId(String? id) {
    for (final model in values) {
      if (model.id == id) return model;
    }
    return v10_2Previous8Step;
  }
}

const double gestureClassifierMaximumHistoryMs = 900;
const double gestureClassifierMinimumHistoryMs = 500;
const int gestureClassifierMinimumValidFrames = 4;

class MobileGestureClassifierStatus {
  const MobileGestureClassifierStatus({
    this.state = 'initializing',
    this.waitingReason = 'loading model',
    this.rawPrediction,
    this.control,
    this.inferenceMs,
    this.replacedWindows = 0,
    this.error,
    this.inferenceEnabled = true,
    this.controlEnabled = true,
    this.modelId = 'v10.2 previous 8-step · 6904a089f23c',
  });

  final String state;
  final String waitingReason;
  final Map<String, dynamic>? rawPrediction;
  final Map<String, dynamic>? control;
  final double? inferenceMs;
  final int replacedWindows;
  final String? error;
  final bool inferenceEnabled;
  final bool controlEnabled;
  final String modelId;

  String get predictionLabel => rawPrediction?['label'] as String? ?? 'waiting';
  double? get predictionConfidence =>
      (rawPrediction?['confidence'] as num?)?.toDouble();
  String? get activeCommand =>
      control?['display_label'] as String? ??
      control?['active_command'] as String?;
}

class MobileGestureClassifier {
  MobileGestureClassifier({
    this.onStatus,
    MobileGestureModel model = MobileGestureModel.v10_2Previous8Step,
    MobileGestureRuntime? runtime,
  }) : _selectedModel = model,
       _runtime = runtime ?? MobileGestureRuntime() {
    _runtime.retain();
  }

  final void Function(MobileGestureClassifierStatus status)? onStatus;
  final MobileGestureRuntime _runtime;
  ScaleUpGestureController? _controller;
  final List<GestureLandmarkFrame> _records = <GestureLandmarkFrame>[];
  List<GestureLandmarkFrame>? _pendingWindow;
  Map<String, dynamic>? _latestPrediction;
  Map<String, dynamic>? _latestControl;
  bool _running = false;
  bool _closed = false;
  bool _enabled = true;
  bool _followSequenceEnabled = false;
  bool _switchingModel = false;
  double? _lastTimestampMs;
  double? _lastScheduledTimestampMs;
  double? _missingHandStartedMs;
  bool _historyClearedForMissingHand = false;
  int _generation = 0;
  int _replacedWindows = 0;
  double? _inferenceMs;
  String _state = 'initializing';
  String _waitingReason = 'loading model';
  String? _error;
  MobileGestureModel _selectedModel;
  Future<void>? _drainFuture;

  GestureModelManifest? get manifest => _runtime.manifest;
  bool get isInitialized => _runtime.isInitialized;
  MobileGestureModel get selectedModel => _selectedModel;
  MobileGestureClassifierStatus get status => MobileGestureClassifierStatus(
    state: _state,
    waitingReason: _waitingReason,
    rawPrediction: _latestPrediction,
    control: _latestControl,
    inferenceMs: _inferenceMs,
    replacedWindows: _replacedWindows,
    error: _error,
    inferenceEnabled: _enabled,
    controlEnabled: true,
    modelId: _selectedModel.id,
  );

  Future<void> setInferenceEnabled(bool enabled) async {
    if (_closed) return;
    if (!enabled) {
      _enabled = false;
      reset(reason: 'gesture inference disabled');
      _state = 'disabled';
      _waitingReason = 'gesture inference off';
      _notify();
      return;
    }
    _enabled = true;
    await initialize();
    _state = 'ready';
    reset(reason: 'filling the first 500 ms window');
  }

  void setFollowSequenceEnabled(bool enabled) {
    _followSequenceEnabled = enabled;
    _controller?.setFollowSequenceEnabled(enabled);
    _latestControl = _controller?.snapshot(_lastTimestampMs ?? 0);
    _notify();
  }

  Future<void> setModel(MobileGestureModel model) async {
    if (_closed || model == _selectedModel) return;
    final shouldInitialize = _enabled && _runtime.isInitialized;
    _switchingModel = true;
    _generation += 1;
    _records.clear();
    _pendingWindow = null;
    _state = 'initializing';
    _waitingReason = 'switching gesture model';
    _notify();
    await _drainFuture;
    _controller = null;
    _latestPrediction = null;
    _latestControl = null;
    _selectedModel = model;
    _switchingModel = false;
    if (shouldInitialize) {
      await initialize();
    } else {
      _state = _enabled ? 'initializing' : 'disabled';
      _waitingReason = _enabled ? 'loading model' : 'gesture inference off';
      _notify();
    }
  }

  Future<void> initialize() async {
    if (_runtime.isInitialized && _runtime.selectedModel == _selectedModel) {
      _initializeController();
      return;
    }
    try {
      await _initialize();
    } catch (error) {
      _state = 'error';
      _error = error.toString();
      _waitingReason = 'model initialization failed';
      _notify();
      rethrow;
    }
  }

  Future<void> _initialize() async {
    _state = 'initializing';
    _error = null;
    _notify();
    await _runtime.setModel(_selectedModel);
    _initializeController();
  }

  void _initializeController() {
    final manifest = _runtime.manifest!;
    _controller = ScaleUpGestureController(
      labels: manifest.labels,
      followSequenceEnabled: _followSequenceEnabled,
    );
    _latestControl = _controller!.snapshot(0);
    _state = _enabled ? 'ready' : 'disabled';
    _waitingReason = _enabled
        ? 'filling the first 500 ms window'
        : 'gesture inference off';
    _notify();
  }

  void submit(Map<String, dynamic> record, {bool runInference = true}) {
    if (_closed || !_enabled || _switchingModel || !isInitialized) return;
    final timestampMs = (record['timestamp_ms'] as num?)?.toDouble();
    if (timestampMs == null || !timestampMs.isFinite) return;
    final detected = record['hand_detected'] == true;
    final rawPoints = record['landmarks_frame_xyz_px'];
    final points = rawPoints is List
        ? <List<double>>[
            for (final rawPoint in rawPoints)
              if (rawPoint is List && rawPoint.length >= 3)
                <double>[
                  (rawPoint[0] as num).toDouble(),
                  (rawPoint[1] as num).toDouble(),
                  (rawPoint[2] as num).toDouble(),
                ],
          ]
        : const <List<double>>[];
    final isRight = record['is_right'] as bool?;
    final frame = GestureLandmarkFrame(
      timestampMs: timestampMs,
      handDetected: detected,
      landmarks: points,
      isRight: isRight,
    );
    _ingest(frame, runInference: runInference);
  }

  void _ingest(GestureLandmarkFrame frame, {required bool runInference}) {
    _lastTimestampMs = frame.timestampMs;

    if (!frame.hasValidLandmarks) {
      if (_missingHandStartedMs == null) {
        _missingHandStartedMs = frame.timestampMs;
        // Match the desktop runtime: a result started before hand loss must
        // never appear later as a delayed prediction.
        _generation += 1;
        _pendingWindow = null;
      }
      final missingDurationMs = frame.timestampMs - _missingHandStartedMs!;
      if (missingDurationMs >= 350) {
        final lost = _controller!.handLost(frame.timestampMs);
        if (lost != null) _latestControl = lost;
        _latestPrediction = null;
        if (!_historyClearedForMissingHand) {
          _clearWindow('no hand for 350 ms: filling a fresh window');
          _historyClearedForMissingHand = true;
        }
      }
    } else {
      _missingHandStartedMs = null;
      _historyClearedForMissingHand = false;
    }

    if (_records.isNotEmpty && frame.timestampMs <= _records.last.timestampMs) {
      _clearWindow('timestamp reset: filling a fresh window');
    }

    if (frame.hasValidLandmarks || !_historyClearedForMissingHand) {
      _records.add(frame);
    }
    while (_records.length >= 2 &&
        frame.timestampMs - _records[1].timestampMs >=
            gestureClassifierMaximumHistoryMs) {
      _records.removeAt(0);
    }
    if (!frame.hasValidLandmarks) {
      _waitingReason = 'short hand gap: inference paused';
      _notify();
      return;
    }
    final validFrames = _records.where((row) => row.hasValidLandmarks).length;
    final durationMs = _records.length < 2
        ? 0.0
        : _records.last.timestampMs - _records.first.timestampMs;
    if (validFrames < gestureClassifierMinimumValidFrames) {
      _waitingReason =
          'filling window: $validFrames/$gestureClassifierMinimumValidFrames valid frames';
      _notify();
      return;
    }
    if (durationMs < gestureClassifierMinimumHistoryMs) {
      _waitingReason =
          'filling time window: ${durationMs.round()}/${gestureClassifierMinimumHistoryMs.round()} ms';
      _notify();
      return;
    }
    if (!runInference) return;
    if (_lastScheduledTimestampMs != null &&
        frame.timestampMs - _lastScheduledTimestampMs! < 1) {
      return;
    }
    _lastScheduledTimestampMs = frame.timestampMs;
    final window = List<GestureLandmarkFrame>.of(_records, growable: false);
    if (_pendingWindow != null) _replacedWindows += 1;
    _pendingWindow = window;
    if (!_running) _startDrain();
  }

  void _startDrain() {
    if (_running || _closed) return;
    final future = _drain();
    _drainFuture = future;
    unawaited(future);
  }

  Future<void> _drain() async {
    _running = true;
    await Future<void>.delayed(Duration.zero);
    try {
      while (!_closed && _pendingWindow != null) {
        final window = _pendingWindow!;
        _pendingWindow = null;
        final generation = _generation;
        final result = await _classify(window);
        if (_closed || generation != _generation) continue;
        _latestPrediction = result;
        _inferenceMs = (result['classifier_inference_ms'] as num).toDouble();
        _waitingReason = 'classification active';
        _state = 'ready';
        _error = null;
        final control = _controller!.process(
          label: result['label'] as String,
          confidence: (result['confidence'] as num).toDouble(),
          nowMs: (result['timestamp_ms'] as num).toDouble(),
          probabilities: Map<String, double>.from(
            result['probabilities'] as Map<String, dynamic>,
          ),
        );
        _latestControl = control;
        _notify();
      }
    } catch (error) {
      _state = 'error';
      _error = error.toString();
      _waitingReason = 'classifier error';
      _notify();
    } finally {
      _running = false;
      _drainFuture = null;
      if (!_closed && _pendingWindow != null) _startDrain();
    }
  }

  Future<Map<String, dynamic>> _classify(
    List<GestureLandmarkFrame> window,
  ) async {
    return _runtime.classify(window);
  }

  void reset({String reason = 'classifier reset: filling a fresh window'}) {
    if (!_enabled) reason = 'gesture inference off';
    _generation += 1;
    _records.clear();
    _pendingWindow = null;
    _lastTimestampMs = null;
    _lastScheduledTimestampMs = null;
    _missingHandStartedMs = null;
    _historyClearedForMissingHand = false;
    _latestPrediction = null;
    _controller?.rearm();
    _latestControl = _controller?.snapshot(0);
    _waitingReason = reason;
    _notify();
  }

  void _clearWindow(String reason, {bool clearPrediction = true}) {
    _generation += 1;
    _records.clear();
    _pendingWindow = null;
    _lastScheduledTimestampMs = null;
    if (clearPrediction) _latestPrediction = null;
    _waitingReason = reason;
  }

  Map<String, dynamic> get telemetryFields {
    final manifest = _runtime.manifest;
    final classifierEnabled = _enabled && manifest != null;
    final fields = <String, dynamic>{
      'gesture_classifier_enabled': classifierEnabled,
      'gesture_classifier_requested_enabled': _enabled,
      'gesture_control_enabled': classifierEnabled,
      'gesture_classifier_state': _state,
      'gesture_classifier_waiting_reason': _waitingReason,
      'gesture_output_schema_version': 1,
      'gesture_output_source': 'mobile_on_device',
      'gesture_output_available':
          classifierEnabled && _latestPrediction != null,
      'gesture_classifier_model_id': _selectedModel.id,
    };
    if (!classifierEnabled) return fields;
    fields.addAll(<String, dynamic>{
      'gesture_classifier_model': manifest.modelName,
      'gesture_classifier_model_asset': _selectedModel.modelAsset,
      'gesture_classifier_model_sha256': manifest.modelSha256,
      'gesture_classifier_model_bytes': manifest.modelBytes,
      'gesture_classifier_backend': 'LiteRT CPU INT8',
      'gesture_classifier_input_shape': manifest.input.shape,
      'gesture_classifier_labels': manifest.labels,
      'gesture_classifier_window_ms': gestureClassifierMaximumHistoryMs,
      'gesture_classifier_maximum_history_ms':
          gestureClassifierMaximumHistoryMs,
      'gesture_classifier_minimum_history_ms':
          gestureClassifierMinimumHistoryMs,
      'gesture_classifier_window_definition':
          'timestamp_bounded_resampled_to_fixed_steps',
      'gesture_classifier_steps': manifest.steps,
      'gesture_classifier_stride_ms': 1,
      'gesture_classifier_minimum_valid_frames':
          gestureClassifierMinimumValidFrames,
      'gesture_classifier_confidence_threshold': 0.80,
      'gesture_detection_policy_version': scaleUpLowLatencyPolicyVersion,
      'gesture_classifier_inference_ms': _inferenceMs,
      'gesture_classifier_queue_depth': _pendingWindow == null ? 0 : 1,
      'gesture_classifier_replaced_windows': _replacedWindows,
      'gesture_classifier_error': _error,
      'gesture_prediction': _latestPrediction,
      'gesture_control': _latestControl,
    });
    return fields;
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    _generation += 1;
    _pendingWindow = null;
    await _drainFuture;
    await _runtime.release();
  }

  void _notify() {
    if (!_closed) onStatus?.call(status);
  }
}

class MobileGestureRuntime {
  GestureModelManifest? _manifest;
  Interpreter? _interpreter;
  IsolateInterpreter? _isolateInterpreter;
  MobileGestureModel? _selectedModel;
  Future<void> _queue = Future<void>.value();
  int _references = 0;

  GestureModelManifest? get manifest => _manifest;
  bool get isInitialized => _manifest != null;
  MobileGestureModel? get selectedModel => _selectedModel;

  void retain() => _references += 1;

  Future<void> release() async {
    _references -= 1;
    if (_references > 0) return;
    await _queue;
    await _dispose();
  }

  Future<void> setModel(MobileGestureModel model) async {
    if (_manifest != null && _selectedModel == model) return;
    final completer = Completer<void>();
    final previous = _queue;
    _queue = completer.future;
    await previous;
    try {
      if (_manifest != null && _selectedModel == model) return;
      await _dispose();
      final manifestSource = await rootBundle.loadString(model.manifestAsset);
      final manifest = GestureModelManifest.decode(manifestSource);
      final modelData = await rootBundle.load(model.modelAsset);
      final modelBytes = modelData.buffer.asUint8List(
        modelData.offsetInBytes,
        modelData.lengthInBytes,
      );
      final actualHash = sha256.convert(modelBytes).toString();
      if (modelBytes.length != manifest.modelBytes ||
          actualHash != manifest.modelSha256) {
        throw StateError(
          'Gesture model integrity check failed: expected '
          '${manifest.modelSha256}/${manifest.modelBytes}, got '
          '$actualHash/${modelBytes.length}.',
        );
      }
      final interpreter = Interpreter.fromBuffer(modelBytes);
      _validateInterpreter(interpreter, manifest);
      final isolateInterpreter = await IsolateInterpreter.create(
        address: interpreter.address,
        debugName: 'ScaleUpGestureClassifier-${model.id}',
      );
      _manifest = manifest;
      _interpreter = interpreter;
      _isolateInterpreter = isolateInterpreter;
      _selectedModel = model;
    } finally {
      completer.complete();
    }
  }

  Future<Map<String, dynamic>> classify(
    List<GestureLandmarkFrame> window,
  ) async {
    final completer = Completer<void>();
    final previous = _queue;
    _queue = completer.future;
    await previous;
    try {
      final manifest = _manifest!;
      final model = _selectedModel!;
      final processed = preprocessGestureWindow(
        window,
        featureMean: manifest.featureMean,
        featureStd: manifest.featureStd,
        steps: manifest.steps,
        focusAction: manifest.focusAction,
        focusActionForAll: manifest.focusActionForAll,
      );
      final input = Int8List(processed.features.length);
      for (var index = 0; index < input.length; index++) {
        input[index] = _roundHalfToEven(
          processed.features[index] / manifest.input.scale +
              manifest.input.zeroPoint,
        ).clamp(-128, 127);
      }
      final outputs = <int, Object>{};
      for (final contract in manifest.outputs.values) {
        outputs[contract.position] = Int8List(contract.shape.last);
      }
      final watch = Stopwatch()..start();
      await _isolateInterpreter!.runForMultipleInputs(<Object>[input], outputs);
      watch.stop();
      final probabilities = <String, List<double>>{};
      for (final entry in manifest.outputs.entries) {
        final contract = entry.value;
        final quantized = outputs[contract.position]! as Int8List;
        final logits = <double>[
          for (final value in quantized)
            (value - contract.zeroPoint) * contract.scale,
        ];
        probabilities[entry.key] = _softmax(logits);
      }
      final classes = probabilities['class_logits']!;
      final forms = probabilities['form_logits']!;
      final completions = probabilities['completion_logits']!;
      final classIndex = _argmax(classes);
      final formIndex = _argmax(forms);
      final completionIndex = _argmax(completions);
      return <String, dynamic>{
        'timestamp_ms': window.last.timestampMs,
        'label': manifest.labels[classIndex],
        'confidence': classes[classIndex],
        'above_threshold': classes[classIndex] >= 0.80,
        'probabilities': <String, double>{
          for (var index = 0; index < manifest.labels.length; index++)
            manifest.labels[index]: classes[index],
        },
        'form': manifest.formLabels[formIndex],
        'form_confidence': forms[formIndex],
        'completion': manifest.completionLabels[completionIndex],
        'completion_confidence': completions[completionIndex],
        'completion_applicable': manifest.formLabels[formIndex] == 'DYNAMIC',
        'window_duration_ms': processed.durationMs,
        'raw_frames': processed.rawFrameCount,
        'valid_frames': processed.validFrameCount,
        'coverage': processed.validFrameCount / processed.rawFrameCount,
        'classifier_inference_ms': watch.elapsedMicroseconds / 1000,
        'model_id': model.id,
      };
    } finally {
      completer.complete();
    }
  }

  Future<void> _dispose() async {
    await _isolateInterpreter?.close();
    _isolateInterpreter = null;
    _interpreter?.close();
    _interpreter = null;
    _manifest = null;
    _selectedModel = null;
  }

  void _validateInterpreter(
    Interpreter interpreter,
    GestureModelManifest manifest,
  ) {
    final input = interpreter.getInputTensor(0);
    if (input.type != TensorType.int8 ||
        !_sameShape(input.shape, manifest.input.shape)) {
      throw StateError(
        'Gesture model input tensor does not match its manifest.',
      );
    }
    _validateQuantization(input.params, manifest.input, 'input');
    final outputTensors = interpreter.getOutputTensors();
    if (outputTensors.length != manifest.outputs.length) {
      throw StateError(
        'Gesture model output count does not match its manifest.',
      );
    }
    for (final contract in manifest.outputs.values) {
      final tensor = outputTensors[contract.position];
      if (tensor.type != TensorType.int8 ||
          !_sameShape(tensor.shape, contract.shape)) {
        throw StateError('${contract.semanticName} tensor contract mismatch.');
      }
      _validateQuantization(tensor.params, contract, contract.semanticName);
    }
  }

  void _validateQuantization(
    QuantizationParams actual,
    GestureTensorContract expected,
    String name,
  ) {
    if ((actual.scale - expected.scale).abs() > 1e-7 ||
        actual.zeroPoint != expected.zeroPoint) {
      throw StateError('$name quantization does not match the manifest.');
    }
  }

  static List<double> _softmax(List<double> logits) {
    final maximum = logits.reduce(math.max);
    final exponentials = <double>[
      for (final value in logits) math.exp(value - maximum),
    ];
    final total = exponentials.fold<double>(0, (sum, value) => sum + value);
    return <double>[for (final value in exponentials) value / total];
  }

  static int _argmax(List<double> values) {
    var selected = 0;
    for (var index = 1; index < values.length; index++) {
      if (values[index] > values[selected]) selected = index;
    }
    return selected;
  }

  static int _roundHalfToEven(double value) {
    final lower = value.floor();
    final fraction = value - lower;
    if (fraction < 0.5) return lower;
    if (fraction > 0.5) return lower + 1;
    return lower.isEven ? lower : lower + 1;
  }

  static bool _sameShape(List<int> left, List<int> right) {
    if (left.length != right.length) return false;
    for (var index = 0; index < left.length; index++) {
      if (left[index] != right[index]) return false;
    }
    return true;
  }
}
