import 'dart:math' as math;

const Set<String> scaleUpGestureLabels = <String>{
  'NO_GESTURE',
  'MOVE_LEFT',
  'MOVE_RIGHT',
  'MOVE_UP',
  'MOVE_DOWN',
  'ZOOM_IN',
  'ZOOM_OUT',
  'INDEX_CIRCLE',
  'FOLLOW_LOCK',
  'FOLLOW_UNLOCK',
  'FIST',
  'OK',
  'PHONE_POSE',
  'THUMBS_UP',
  'VICTORY',
};

const Set<String> staticGestureLabels = <String>{
  'FIST',
  'OK',
  'PHONE_POSE',
  'THUMBS_UP',
  'VICTORY',
};

const String scaleUpLowLatencyPolicyVersion = 'SCALE_UP_FIXED_CONTINUOUS_V4';

class GestureVote {
  const GestureVote(this.timestampMs, this.label);

  final double timestampMs;
  final String label;
}

/// Matches the PC scale-up low-latency controller.
///
/// Three rolling classifier results are retained and a label is confirmed when
/// at least two agree. After emitting a dynamic command, the same command is
/// suppressed until neutral is confirmed. Inference continues throughout.
class ScaleUpGestureController {
  ScaleUpGestureController({
    required List<String> labels,
    this.confidenceThreshold = 0.80,
    this.followSequenceEnabled = false,
  }) {
    final labelSet = labels.toSet();
    if (labels.isEmpty ||
        labels.first != 'NO_GESTURE' ||
        labelSet.length != labels.length ||
        !scaleUpGestureLabels.containsAll(labelSet)) {
      throw ArgumentError('Controller requires an approved label subset.');
    }
    _allowedLabels = labelSet;
  }

  static const int requiredMatches = 2;
  static const int evidenceSize = 3;
  static const int staticConsecutiveMatches = 2;
  static const double strongConfidenceFloor = 0.92;
  static const double strongMarginFloor = 0.25;
  static const double displayHoldMs = 400;

  final double confidenceThreshold;
  bool followSequenceEnabled;
  late final Set<String> _allowedLabels;
  final List<GestureVote> _votes = <GestureVote>[];
  String? _heldLabel;
  String? _heldMode;
  String? _dynamicLabelAwaitingNeutral;
  String? _lastEmittedLabel;
  String? _displayLabel;
  double _displayUntilMs = 0;
  String _latestEvent = 'INITIALIZED';
  bool _handMissing = false;
  bool _enabled = true;
  bool _followLocked = false;
  String? _staticCandidate;
  int _staticCandidateCount = 0;

  bool get enabled => _enabled;

  void setEnabled(bool enabled) {
    if (_enabled == enabled) return;
    _enabled = enabled;
    rearm();
    if (!enabled) _latestEvent = 'CONTROL_DISABLED';
  }

  void setFollowSequenceEnabled(bool enabled) {
    if (followSequenceEnabled == enabled) return;
    followSequenceEnabled = enabled;
    rearm();
  }

  Map<String, dynamic> process({
    required String label,
    required double confidence,
    required double nowMs,
    Map<String, double>? probabilities,
  }) {
    _handMissing = false;
    if (!_enabled) return _event('CONTROL_DISABLED', nowMs);

    var voteLabel =
        _allowedLabels.contains(label) && confidence >= confidenceThreshold
        ? label
        : 'NO_GESTURE';
    if (followSequenceEnabled &&
        voteLabel == 'FOLLOW_UNLOCK' &&
        !_followLocked) {
      voteLabel = 'NO_GESTURE';
      _votes.add(GestureVote(nowMs, voteLabel));
      if (_votes.length > evidenceSize) _votes.removeAt(0);
      return _event('FOLLOW_SEQUENCE_SUPPRESSED', nowMs);
    }
    if (followSequenceEnabled &&
        _followLocked &&
        voteLabel != 'NO_GESTURE' &&
        voteLabel != 'FOLLOW_UNLOCK') {
      voteLabel = 'NO_GESTURE';
      _votes.add(GestureVote(nowMs, voteLabel));
      if (_votes.length > evidenceSize) _votes.removeAt(0);
      return _event('GESTURE_CONFLICT_SUPPRESSED', nowMs);
    }
    _votes.add(GestureVote(nowMs, voteLabel));
    if (_votes.length > evidenceSize) _votes.removeAt(0);

    if (staticGestureLabels.contains(voteLabel)) {
      if (_staticCandidate == voteLabel) {
        _staticCandidateCount += 1;
      } else {
        _staticCandidate = voteLabel;
        _staticCandidateCount = 1;
      }
      if (_staticCandidateCount >= staticConsecutiveMatches) {
        return _accept(voteLabel, nowMs);
      }
    } else {
      _staticCandidate = null;
      _staticCandidateCount = 0;
    }

    if (probabilities != null &&
        voteLabel != 'NO_GESTURE' &&
        !staticGestureLabels.contains(voteLabel)) {
      final alternatives = probabilities.entries
          .where((entry) => entry.key != voteLabel)
          .map((entry) => entry.value);
      final runnerUp = alternatives.fold<double>(
        0,
        (current, value) => value > current ? value : current,
      );
      if (confidence >= math.max(strongConfidenceFloor, confidenceThreshold) &&
          confidence - runnerUp >= strongMarginFloor) {
        return _accept(voteLabel, nowMs);
      }
    }
    if (_votes.length < evidenceSize) {
      return _event('COLLECTING_EVIDENCE', nowMs);
    }

    final counts = _voteCounts();
    String? winner;
    var winnerCount = 0;
    for (final entry in counts.entries) {
      if (entry.value > winnerCount) {
        winner = entry.key;
        winnerCount = entry.value;
      }
    }
    if (winner == null || winnerCount < requiredMatches) {
      return _event('UNSTABLE', nowMs);
    }

    if (winner == 'NO_GESTURE') {
      final released = _heldLabel ?? _dynamicLabelAwaitingNeutral;
      _heldLabel = null;
      _heldMode = null;
      _dynamicLabelAwaitingNeutral = null;
      _lastEmittedLabel = null;
      _staticCandidate = null;
      _staticCandidateCount = 0;
      return _event(
        'NO_GESTURE_CONFIRMED',
        nowMs,
        releasedLabel: released,
        stateChanged: released != null,
      );
    }

    if (staticGestureLabels.contains(winner)) {
      return _event('STATIC_UNCONFIRMED', nowMs);
    }
    return _accept(winner, nowMs);
  }

  Map<String, dynamic> _accept(String winner, double nowMs) {
    if (followSequenceEnabled && winner == 'FOLLOW_UNLOCK' && !_followLocked) {
      return _event(
        'FOLLOW_SEQUENCE_SUPPRESSED',
        nowMs,
        suppressedDirection: winner,
      );
    }
    if (followSequenceEnabled && _followLocked && winner != 'FOLLOW_UNLOCK') {
      return _event(
        'GESTURE_CONFLICT_SUPPRESSED',
        nowMs,
        suppressedDirection: winner,
      );
    }
    if (staticGestureLabels.contains(winner) && _heldLabel == winner) {
      return _event('STATIC_CONFIRMED', nowMs);
    }
    if (!staticGestureLabels.contains(winner) &&
        _dynamicLabelAwaitingNeutral == winner) {
      return _event('DUPLICATE_SUPPRESSED', nowMs);
    }
    final released = _heldLabel ?? _dynamicLabelAwaitingNeutral;
    if (staticGestureLabels.contains(winner)) {
      _heldLabel = winner;
      _heldMode = 'STATIC';
      _dynamicLabelAwaitingNeutral = null;
    } else {
      _heldLabel = null;
      _heldMode = null;
      _dynamicLabelAwaitingNeutral = winner;
    }
    _lastEmittedLabel = winner;
    _show(winner, nowMs);
    var event = 'COMMAND_EMITTED';
    if (followSequenceEnabled && winner == 'FOLLOW_LOCK') {
      _followLocked = true;
      event = 'FOLLOW_LOCKED';
    } else if (followSequenceEnabled && winner == 'FOLLOW_UNLOCK') {
      _followLocked = false;
      event = 'FOLLOW_UNLOCKED';
    }
    return _event(
      event,
      nowMs,
      emittedCommand: winner,
      commandEmitted: true,
      commandHoldRequired: false,
      stateChanged: true,
      releasedLabel: released,
    );
  }

  Map<String, dynamic>? advance(double nowMs) => null;

  Map<String, dynamic>? handLost(double nowMs) {
    if (_handMissing &&
        _votes.isEmpty &&
        _heldLabel == null &&
        _dynamicLabelAwaitingNeutral == null) {
      return null;
    }
    final released = _heldLabel ?? _dynamicLabelAwaitingNeutral;
    _handMissing = true;
    _votes.clear();
    _heldLabel = null;
    _heldMode = null;
    _dynamicLabelAwaitingNeutral = null;
    _lastEmittedLabel = null;
    _displayLabel = null;
    _displayUntilMs = 0;
    _staticCandidate = null;
    _staticCandidateCount = 0;
    return _event(
      followSequenceEnabled && _followLocked
          ? 'HAND_LOST_FOLLOW_MODE_RETAINED'
          : 'HAND_LOST_REARMED',
      nowMs,
      releasedLabel: released,
      stateChanged: released != null,
    );
  }

  void rearm() {
    _votes.clear();
    _heldLabel = null;
    _heldMode = null;
    _dynamicLabelAwaitingNeutral = null;
    _lastEmittedLabel = null;
    _displayLabel = null;
    _displayUntilMs = 0;
    _latestEvent = _enabled ? 'MANUALLY_REARMED' : 'CONTROL_DISABLED';
    _handMissing = false;
    _followLocked = false;
    _staticCandidate = null;
    _staticCandidateCount = 0;
  }

  Map<String, dynamic> snapshot(double nowMs) {
    final counts = _voteCounts();
    String? candidateLabel;
    var candidateCount = 0;
    for (final entry in counts.entries) {
      if (entry.value > candidateCount) {
        candidateLabel = entry.key;
        candidateCount = entry.value;
      }
    }
    final visibleLabel = nowMs < _displayUntilMs ? _displayLabel : null;
    return <String, dynamic>{
      'type': 'SCALE_UP_QUORUM_CONTINUOUS',
      'policy_version': scaleUpLowLatencyPolicyVersion,
      'enabled': _enabled,
      'state': !_enabled
          ? 'DISABLED'
          : followSequenceEnabled && _followLocked
          ? 'FOLLOW_LOCKED'
          : _heldLabel != null
          ? 'STATIC_ACTIVE'
          : _dynamicLabelAwaitingNeutral != null
          ? 'WAITING_FOR_NEUTRAL'
          : _votes.isNotEmpty
          ? 'CONFIRMING'
          : 'ARMED',
      'confidence_threshold': confidenceThreshold,
      'vote_span_ms': _voteSpanMs,
      'vote_count': _votes.length,
      'vote_counts': counts,
      'required_matches': requiredMatches,
      'evidence_size': evidenceSize,
      'static_consecutive_matches': staticConsecutiveMatches,
      'strong_confidence_floor': strongConfidenceFloor,
      'strong_margin_floor': strongMarginFloor,
      'candidate_label': candidateLabel,
      'held_label': _heldLabel,
      'held_mode': _heldMode,
      'active_command': _heldLabel,
      'duplicate_suppression_label': _dynamicLabelAwaitingNeutral,
      'last_emitted_label': _lastEmittedLabel,
      'last_emitted_command': _lastEmittedLabel,
      'follow_sequence_enabled': followSequenceEnabled,
      'follow_locked': _followLocked,
      'display_label': visibleLabel,
      'display_remaining_ms': (_displayUntilMs - nowMs).clamp(
        0,
        double.infinity,
      ),
      'event': _latestEvent,
    };
  }

  Map<String, int> _voteCounts() {
    final counts = <String, int>{};
    for (final vote in _votes) {
      counts[vote.label] = (counts[vote.label] ?? 0) + 1;
    }
    return counts;
  }

  double get _voteSpanMs => _votes.length < 2
      ? 0
      : (_votes.last.timestampMs - _votes.first.timestampMs).clamp(
          0,
          double.infinity,
        );

  void _show(String label, double nowMs) {
    _displayLabel = label;
    _displayUntilMs = nowMs + displayHoldMs;
  }

  Map<String, dynamic> _event(
    String event,
    double nowMs, {
    String? emittedCommand,
    bool commandEmitted = false,
    bool commandHoldRequired = false,
    bool stateChanged = false,
    String? releasedLabel,
    String? suppressedDirection,
  }) {
    _latestEvent = event;
    return <String, dynamic>{
      ...snapshot(nowMs),
      'event': event,
      'emitted_command': emittedCommand,
      'effective_label': emittedCommand,
      'effective_direction': emittedCommand,
      'command_emitted': commandEmitted,
      'command_hold_required': commandHoldRequired,
      'state_changed': stateChanged,
      'released_label': releasedLabel,
      'suppressed_direction': suppressedDirection,
    };
  }
}
