import 'dart:math' as math;
import 'dart:typed_data';

const int gestureLandmarkCount = 21;
const int gestureModelSteps = 8;
const int gestureBaseFeatureCount = 76;
const int gestureFusionFeatureCount = 139;
const double _epsilon = 1e-6;
const List<int> _palmIndices = <int>[0, 5, 9, 13, 17];

class GestureLandmarkFrame {
  GestureLandmarkFrame({
    required this.timestampMs,
    required this.handDetected,
    required List<List<double>> landmarks,
    required this.isRight,
  }) : landmarks = <List<double>>[
         for (final point in landmarks) List<double>.of(point, growable: false),
       ];

  final double timestampMs;
  final bool handDetected;
  final List<List<double>> landmarks;
  final bool? isRight;

  bool get hasValidLandmarks =>
      handDetected &&
      landmarks.length == gestureLandmarkCount &&
      landmarks.every(
        (point) => point.length >= 3 && point.take(3).every((v) => v.isFinite),
      );
}

class GesturePreprocessResult {
  const GesturePreprocessResult({
    required this.features,
    required this.durationMs,
    required this.rawFrameCount,
    required this.validFrameCount,
  });

  final Float32List features;
  final double durationMs;
  final int rawFrameCount;
  final int validFrameCount;
}

GesturePreprocessResult preprocessGestureWindow(
  List<GestureLandmarkFrame> rows, {
  required List<double> featureMean,
  required List<double> featureStd,
  int steps = 8,
  bool focusAction = true,
  bool focusActionForAll = true,
}) {
  if (rows.length < 2) {
    throw const FormatException('Gesture window requires at least two rows.');
  }
  if (featureMean.length != gestureFusionFeatureCount ||
      featureStd.length != gestureFusionFeatureCount) {
    throw const FormatException('Gesture normalization must have 139 values.');
  }
  if (steps != 8 && steps != 16) {
    throw const FormatException('Gesture model steps must be 8 or 16.');
  }
  var startMs = rows.first.timestampMs;
  var endMs = rows.last.timestampMs;
  if (endMs <= startMs) {
    throw const FormatException('Gesture timestamps must be increasing.');
  }
  final validRows = rows.where((row) => row.hasValidLandmarks).toList();
  if (validRows.length < 2) {
    throw const FormatException('Gesture window requires two valid frames.');
  }
  if (focusAction && focusActionForAll) {
    final actionWindow = _detectActionWindow(rows, validRows);
    startMs = actionWindow.$1;
    endMs = actionWindow.$2;
  }

  final targetTimes = List<double>.generate(
    steps,
    (index) => startMs + index * (endMs - startMs) / (steps - 1),
    growable: false,
  );
  final resampled = <List<List<double>>>[
    for (final target in targetTimes) _interpolate(validRows, target),
  ];
  final centers = <List<double>>[
    for (final points in resampled) _meanPoints(points, _palmIndices),
  ];
  final scales = <double>[
    for (final points in resampled)
      math.max(
        math.max(
          _distance(points[0], points[9]),
          _distance(points[5], points[17]),
        ),
        _epsilon,
      ),
  ];
  final anchorCenter = centers.first;
  final anchorScale = scales.first;
  final localShapes = <List<double>>[];
  final displacements = <List<double>>[];
  final scaleChanges = <double>[];
  for (var step = 0; step < steps; step++) {
    final local = <double>[];
    for (final point in resampled[step]) {
      for (var axis = 0; axis < 3; axis++) {
        local.add((point[axis] - centers[step][axis]) / scales[step]);
      }
    }
    localShapes.add(local);
    displacements.add(<double>[
      for (var axis = 0; axis < 3; axis++)
        (centers[step][axis] - anchorCenter[axis]) / anchorScale,
    ]);
    scaleChanges.add(math.log(scales[step] / anchorScale));
  }

  final elapsed = <double>[
    for (final timestamp in targetTimes) (timestamp - targetTimes.first) / 1000,
  ];
  final dt = <double>[
    0,
    for (var step = 1; step < steps; step++)
      (targetTimes[step] - targetTimes[step - 1]) / 1000,
  ];
  final velocity = <List<double>>[
    const <double>[0, 0, 0],
  ];
  for (var step = 1; step < steps; step++) {
    velocity.add(<double>[
      for (var axis = 0; axis < 3; axis++)
        (displacements[step][axis] - displacements[step - 1][axis]) /
            math.max(dt[step], _epsilon),
    ]);
  }
  final acceleration = <List<double>>[
    const <double>[0, 0, 0],
  ];
  for (var step = 1; step < steps; step++) {
    acceleration.add(<double>[
      for (var axis = 0; axis < 3; axis++)
        (velocity[step][axis] - velocity[step - 1][axis]) /
            math.max(dt[step], _epsilon),
    ]);
  }
  final validity = <double>[
    for (final target in targetTimes)
      _nearestRow(rows, target).handDetected ? 1 : 0,
  ];

  final base = <List<double>>[];
  for (var step = 0; step < steps; step++) {
    base.add(<double>[
      ...localShapes[step],
      ...displacements[step],
      ...velocity[step],
      ...acceleration[step],
      scaleChanges[step],
      dt[step],
      elapsed[step],
      validity[step],
    ]);
  }

  final standardized = Float32List(steps * gestureFusionFeatureCount);
  for (var step = 0; step < steps; step++) {
    final localVelocity = List<double>.filled(63, 0);
    if (step > 0 && base[step][75] > 0.5 && base[step - 1][75] > 0.5) {
      for (var feature = 0; feature < 63; feature++) {
        localVelocity[feature] =
            (base[step][feature] - base[step - 1][feature]) /
            math.max(base[step][73], _epsilon);
      }
    }
    final fusion = <double>[
      ...base[step].sublist(0, 63),
      ...localVelocity,
      ...base[step].sublist(63, gestureBaseFeatureCount),
    ];
    for (var feature = 0; feature < gestureFusionFeatureCount; feature++) {
      standardized[step * gestureFusionFeatureCount + feature] =
          (fusion[feature] - featureMean[feature]) / featureStd[feature];
    }
  }
  return GesturePreprocessResult(
    features: standardized,
    durationMs: endMs - startMs,
    rawFrameCount: rows.length,
    validFrameCount: validRows.length,
  );
}

List<List<double>> _interpolate(
  List<GestureLandmarkFrame> validRows,
  double targetMs,
) {
  var right = 0;
  while (right < validRows.length && validRows[right].timestampMs < targetMs) {
    right++;
  }
  if (right == 0) return _copyPoints(validRows.first.landmarks);
  if (right >= validRows.length) return _copyPoints(validRows.last.landmarks);
  if (validRows[right].timestampMs == targetMs) {
    return _copyPoints(validRows[right].landmarks);
  }
  final left = right - 1;
  final span = math.max(
    validRows[right].timestampMs - validRows[left].timestampMs,
    _epsilon,
  );
  final ratio = (targetMs - validRows[left].timestampMs) / span;
  return <List<double>>[
    for (var point = 0; point < gestureLandmarkCount; point++)
      <double>[
        for (var axis = 0; axis < 3; axis++)
          validRows[left].landmarks[point][axis] +
              (validRows[right].landmarks[point][axis] -
                      validRows[left].landmarks[point][axis]) *
                  ratio,
      ],
  ];
}

GestureLandmarkFrame _nearestRow(
  List<GestureLandmarkFrame> rows,
  double targetMs,
) {
  var nearest = rows.first;
  var distance = (nearest.timestampMs - targetMs).abs();
  for (final row in rows.skip(1)) {
    final candidate = (row.timestampMs - targetMs).abs();
    if (candidate < distance) {
      nearest = row;
      distance = candidate;
    }
  }
  return nearest;
}

List<double> _meanPoints(List<List<double>> points, List<int> indices) =>
    <double>[
      for (var axis = 0; axis < 3; axis++)
        indices.fold<double>(0, (sum, index) => sum + points[index][axis]) /
            indices.length,
    ];

double _distance(List<double> left, List<double> right) => math.sqrt(
  List<double>.generate(
    3,
    (axis) => math.pow(left[axis] - right[axis], 2).toDouble(),
  ).fold<double>(0, (sum, value) => sum + value),
);

List<List<double>> _copyPoints(List<List<double>> points) => <List<double>>[
  for (final point in points) List<double>.of(point, growable: false),
];

(double, double) _detectActionWindow(
  List<GestureLandmarkFrame> rows,
  List<GestureLandmarkFrame> validRows,
) {
  const contextMs = 150.0;
  const minimumWindowMs = 500.0;
  final recordingStart = rows.first.timestampMs;
  final recordingEnd = rows.last.timestampMs;
  if (validRows.length < 4 || recordingEnd <= recordingStart) {
    return (recordingStart, recordingEnd);
  }
  final times = <double>[for (final row in validRows) row.timestampMs];
  final centers = <List<double>>[
    for (final row in validRows) _meanPoints(row.landmarks, _palmIndices),
  ];
  final scales = <double>[
    for (final row in validRows)
      math.max(
        math.max(
          _distance(row.landmarks[0], row.landmarks[9]),
          _distance(row.landmarks[5], row.landmarks[17]),
        ),
        _epsilon,
      ),
  ];
  final shapes = <List<List<double>>>[
    for (var frame = 0; frame < validRows.length; frame++)
      <List<double>>[
        for (final point in validRows[frame].landmarks)
          <double>[
            (point[0] - centers[frame][0]) / scales[frame],
            (point[1] - centers[frame][1]) / scales[frame],
          ],
      ],
  ];
  final energy = <double>[];
  final bounds = <(double, double)>[];
  final intervals = <double>[];
  for (var index = 1; index < validRows.length; index++) {
    final dt = math.max((times[index] - times[index - 1]) / 1000, _epsilon);
    final meanScale = math.max(
      (scales[index] + scales[index - 1]) / 2,
      _epsilon,
    );
    final palmSpeed =
        math.sqrt(
          math.pow(centers[index][0] - centers[index - 1][0], 2) +
              math.pow(centers[index][1] - centers[index - 1][1], 2),
        ) /
        meanScale /
        dt;
    var shapeDelta = 0.0;
    for (var point = 0; point < gestureLandmarkCount; point++) {
      for (var axis = 0; axis < 2; axis++) {
        shapeDelta += math.pow(
          shapes[index][point][axis] - shapes[index - 1][point][axis],
          2,
        );
      }
    }
    final shapeSpeed = math.sqrt(shapeDelta / 42) / dt;
    final scaleSpeed = (math.log(scales[index] / scales[index - 1])).abs() / dt;
    energy.add(
      math.sqrt(
        palmSpeed * palmSpeed +
            math.pow(1.5 * shapeSpeed, 2) +
            math.pow(0.5 * scaleSpeed, 2),
      ),
    );
    bounds.add((times[index - 1], times[index]));
    intervals.add(dt);
  }
  if (energy.length < 3) return (recordingStart, recordingEnd);
  final median = _percentile(energy, 0.5);
  final mad = _percentile(<double>[
    for (final value in energy) (value - median).abs(),
  ], 0.5);
  final cap = math.max(
    _percentile(energy, 0.9) * 1.5,
    median + 8 * math.max(mad, _epsilon),
  );
  final limited = <double>[for (final value in energy) math.min(value, cap)];
  final smoothed = <double>[
    for (var index = 0; index < limited.length; index++)
      _percentile(
        limited.sublist(
          math.max(0, index - 1),
          math.min(limited.length, index + 2),
        ),
        0.5,
      ),
  ];
  final baseline = _percentile(smoothed, 0.2);
  final smoothMedian = _percentile(smoothed, 0.5);
  final smoothMad = _percentile(<double>[
    for (final value in smoothed) (value - smoothMedian).abs(),
  ], 0.5);
  final peak = smoothed.reduce(math.max);
  final threshold =
      baseline +
      math.max(
        2.5 * smoothMad,
        math.max(0.1 * math.max(peak - baseline, 0), 0.05),
      );
  final weights = <double>[
    for (var index = 0; index < smoothed.length; index++)
      math.max(smoothed[index] - threshold, 0) * intervals[index],
  ];
  final active = <int>[
    for (var index = 0; index < weights.length; index++)
      if (weights[index] > 0) index,
  ];
  if (active.isEmpty) return (recordingStart, recordingEnd);
  final activeSpan = bounds[active.last].$2 - bounds[active.first].$1;
  if (active.length < 2 && activeSpan < 100) {
    return (recordingStart, recordingEnd);
  }
  final total = weights.fold<double>(0, (sum, value) => sum + value);
  var cumulative = 0.0;
  var lower = active.first;
  var upper = active.last;
  var lowerFound = false;
  for (var index = 0; index < weights.length; index++) {
    cumulative += weights[index];
    if (!lowerFound && cumulative >= total * 0.01) {
      lower = index;
      lowerFound = true;
    }
    if (cumulative >= total * 0.99) {
      upper = index;
      break;
    }
  }
  final coreStart = bounds[lower].$1;
  final coreEnd = bounds[upper].$2;
  var start = math.max(recordingStart, coreStart - contextMs);
  var end = math.min(recordingEnd, coreEnd + contextMs);
  if (end - start < minimumWindowMs) {
    final center = (coreStart + coreEnd) / 2;
    start = math.max(recordingStart, center - minimumWindowMs / 2);
    end = math.min(recordingEnd, start + minimumWindowMs);
    start = math.max(recordingStart, end - minimumWindowMs);
  }
  return (start, end);
}

double _percentile(List<double> values, double ratio) {
  if (values.isEmpty) return 0;
  final ordered = List<double>.of(values)..sort();
  final position = ratio.clamp(0.0, 1.0) * (ordered.length - 1);
  final lower = position.floor();
  final upper = position.ceil();
  if (lower == upper) return ordered[lower];
  return ordered[lower] +
      (ordered[upper] - ordered[lower]) * (position - lower);
}
