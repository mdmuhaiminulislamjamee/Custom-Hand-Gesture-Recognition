import 'dart:async';

import 'gesture_classifier/mobile_gesture_classifier.dart';

enum GesturePhysicalHand { left, right }

class GestureApiHand {
  GestureApiHand({
    required this.hand,
    required List<List<double>> normalizedLandmarks,
  }) : normalizedLandmarks = <List<double>>[
         for (final point in normalizedLandmarks)
           List<double>.of(point, growable: false),
       ] {
    if (this.normalizedLandmarks.length != 21 ||
        this.normalizedLandmarks.any(
          (point) => point.length != 3 || point.any((value) => !value.isFinite),
        )) {
      throw const FormatException(
        'Each detected hand must contain exactly 21 finite x/y/z landmarks.',
      );
    }
  }

  final GesturePhysicalHand hand;

  /// Canonical MediaPipe ordering. x and y are normalized by frame width and
  /// height; z is normalized by frame width. Coordinates must describe the
  /// unmirrored, upright source frame.
  final List<List<double>> normalizedLandmarks;
}

class GestureApiFrame {
  GestureApiFrame({
    required this.timestampMs,
    required this.frameWidth,
    required this.frameHeight,
    required List<GestureApiHand> hands,
  }) : hands = List<GestureApiHand>.of(hands, growable: false) {
    if (!timestampMs.isFinite || timestampMs < 0) {
      throw const FormatException(
        'timestampMs must be a finite monotonic millisecond timestamp.',
      );
    }
    if (!frameWidth.isFinite ||
        !frameHeight.isFinite ||
        frameWidth <= 0 ||
        frameHeight <= 0) {
      throw const FormatException('Frame dimensions must be positive.');
    }
    if (this.hands.length > 2 ||
        this.hands.map((item) => item.hand).toSet().length !=
            this.hands.length) {
      throw const FormatException(
        'A frame may contain at most one physical left and one physical right hand.',
      );
    }
  }

  final double timestampMs;
  final double frameWidth;
  final double frameHeight;
  final List<GestureApiHand> hands;
}

class GestureCommandEvent {
  const GestureCommandEvent({
    required this.command,
    required this.hand,
    required this.timestampMs,
    required this.confidence,
    required this.modelId,
    required this.followLocked,
  });

  final String command;
  final GesturePhysicalHand hand;
  final double timestampMs;
  final double confidence;
  final String modelId;
  final bool followLocked;

  Map<String, dynamic> toJson() => <String, dynamic>{
    'command': command,
    'hand': hand.name,
    'timestamp_ms': timestampMs,
    'confidence': confidence,
    'model_id': modelId,
    'follow_locked': followLocked,
  };
}

class GestureRuntimeStatus {
  const GestureRuntimeStatus({
    required this.left,
    required this.right,
    required this.lastCommand,
  });

  final MobileGestureClassifierStatus left;
  final MobileGestureClassifierStatus right;
  final GestureCommandEvent? lastCommand;
}

typedef GestureCommandCallback = void Function(GestureCommandEvent event);
typedef GestureRuntimeStatusCallback =
    void Function(GestureRuntimeStatus status);

/// Cross-platform landmarks-in, command-out runtime for Android and iOS.
///
/// The implementation deliberately reuses the same preprocessing, LiteRT
/// decoding, and command controller as the established mobile live test.
class GestureRuntimeApi {
  GestureRuntimeApi({
    this.onCommand,
    this.onStatus,
    required MobileGestureModel model,
    bool followSequenceEnabled = false,
  }) : _model = model,
       _followSequenceEnabled = followSequenceEnabled {
    _runtime = MobileGestureRuntime();
    _right = MobileGestureClassifier(
      runtime: _runtime,
      model: model,
      onStatus: (status) => _handleStatus(GesturePhysicalHand.right, status),
    );
    _left = MobileGestureClassifier(
      runtime: _runtime,
      model: model,
      onStatus: (status) => _handleStatus(GesturePhysicalHand.left, status),
    );
  }

  final GestureCommandCallback? onCommand;
  final GestureRuntimeStatusCallback? onStatus;
  late final MobileGestureRuntime _runtime;
  late final MobileGestureClassifier _right;
  late final MobileGestureClassifier _left;
  MobileGestureModel _model;
  bool _followSequenceEnabled;
  MobileGestureClassifierStatus _rightStatus =
      const MobileGestureClassifierStatus();
  MobileGestureClassifierStatus _leftStatus =
      const MobileGestureClassifierStatus();
  GestureCommandEvent? _lastCommand;
  double? _lastAcceptedWindowTimestampMs;
  bool _initialized = false;
  bool _closed = false;

  MobileGestureModel get model => _model;
  bool get followSequenceEnabled => _followSequenceEnabled;
  GestureRuntimeStatus get status => GestureRuntimeStatus(
    left: _leftStatus,
    right: _rightStatus,
    lastCommand: _lastCommand,
  );

  Future<void> initialize() async {
    if (_closed) throw StateError('GestureRuntimeApi is closed.');
    if (_initialized) return;
    _right.setFollowSequenceEnabled(_followSequenceEnabled);
    _left.setFollowSequenceEnabled(_followSequenceEnabled);
    await _right.initialize();
    await _left.initialize();
    _initialized = true;
  }

  Future<void> setModel(MobileGestureModel model) async {
    if (_closed) throw StateError('GestureRuntimeApi is closed.');
    if (model == _model) return;
    await _right.setModel(model);
    await _left.setModel(model);
    _model = model;
    _lastCommand = null;
    _lastAcceptedWindowTimestampMs = null;
  }

  void setFollowSequenceEnabled(bool enabled) {
    if (_closed) throw StateError('GestureRuntimeApi is closed.');
    _followSequenceEnabled = enabled;
    _right.setFollowSequenceEnabled(enabled);
    _left.setFollowSequenceEnabled(enabled);
    _lastCommand = null;
    _lastAcceptedWindowTimestampMs = null;
  }

  void processFrame(GestureApiFrame frame) {
    if (_closed) throw StateError('GestureRuntimeApi is closed.');
    if (!_initialized) {
      throw StateError('Call initialize() before processFrame().');
    }
    final provided = <GesturePhysicalHand, GestureApiHand>{
      for (final hand in frame.hands) hand.hand: hand,
    };
    for (final hand in frame.hands) {
      _classifier(hand.hand).submit(_record(frame, hand));
    }
    for (final hand in GesturePhysicalHand.values) {
      if (!provided.containsKey(hand)) {
        _classifier(hand).submit(_missingRecord(frame, hand));
      }
    }
  }

  void reset() {
    if (_closed) return;
    _right.reset(reason: 'API reset: filling a fresh rolling window');
    _left.reset(reason: 'API reset: filling a fresh rolling window');
    _lastCommand = null;
    _lastAcceptedWindowTimestampMs = null;
  }

  Future<void> close() async {
    if (_closed) return;
    _closed = true;
    await Future.wait(<Future<void>>[_right.close(), _left.close()]);
  }

  MobileGestureClassifier _classifier(GesturePhysicalHand hand) =>
      hand == GesturePhysicalHand.right ? _right : _left;

  Map<String, dynamic> _record(GestureApiFrame frame, GestureApiHand hand) =>
      <String, dynamic>{
        'timestamp_ms': frame.timestampMs,
        'frame_width': frame.frameWidth.round(),
        'frame_height': frame.frameHeight.round(),
        'hand_detected': true,
        'is_right': hand.hand == GesturePhysicalHand.right,
        'landmarks_frame_xyz_px': <List<double>>[
          for (final point in hand.normalizedLandmarks)
            <double>[
              point[0] * frame.frameWidth,
              point[1] * frame.frameHeight,
              point[2] * frame.frameWidth,
            ],
        ],
      };

  Map<String, dynamic> _missingRecord(
    GestureApiFrame frame,
    GesturePhysicalHand hand,
  ) => <String, dynamic>{
    'timestamp_ms': frame.timestampMs,
    'frame_width': frame.frameWidth.round(),
    'frame_height': frame.frameHeight.round(),
    'hand_detected': false,
    'is_right': hand == GesturePhysicalHand.right,
    'landmarks_frame_xyz_px': const <List<double>>[],
  };

  void _handleStatus(
    GesturePhysicalHand hand,
    MobileGestureClassifierStatus status,
  ) {
    if (_closed) return;
    if (hand == GesturePhysicalHand.right) {
      _rightStatus = status;
    } else {
      _leftStatus = status;
    }
    final control = status.control;
    final prediction = status.rawPrediction;
    if (control?['command_emitted'] == true && prediction != null) {
      final timestampMs = (prediction['timestamp_ms'] as num).toDouble();
      // Both hand windows end on the same source frame. The shared interpreter
      // completes one first; only that first command is exposed.
      if (_lastAcceptedWindowTimestampMs == null ||
          timestampMs > _lastAcceptedWindowTimestampMs!) {
        final event = GestureCommandEvent(
          command: control?['emitted_command'] as String,
          hand: hand,
          timestampMs: timestampMs,
          confidence: (prediction['confidence'] as num).toDouble(),
          modelId: status.modelId,
          followLocked: control?['follow_locked'] == true,
        );
        _lastAcceptedWindowTimestampMs = timestampMs;
        _lastCommand = event;
        onCommand?.call(event);
      }
    }
    onStatus?.call(this.status);
  }
}
