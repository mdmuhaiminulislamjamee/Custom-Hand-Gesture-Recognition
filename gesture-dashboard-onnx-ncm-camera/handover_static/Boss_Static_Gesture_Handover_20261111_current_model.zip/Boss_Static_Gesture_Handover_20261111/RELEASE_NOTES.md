﻿# Current model delivery - 11 November 2026

- Refreshed FP32 TFLite from production ONNX
  `bb1df78e02ec0aaf8d55fe9edb78503d2ca5b473245a15c0cc3f7c37c91de2b2`,
  replacing the 31 October bundle's older `11d6991c...` source. No retraining.
- Matched current scalar gates: confidence .75, margin .10, known mass .70.
  Regenerated conversion, model and geometry fixtures for this source.
- Retained the previous speed policy: 100 ms minimum admission spacing,
  newest pending frame replacement, persistent one-thread classifier,
  immediate strong valid predictions, ordinary two of three confirmation,
  independent hand state and no fixed action cooldown. Geometry recoveries
  keep their existing hold requirements.
- GestureLab 2.0.8 retains the 2.0.7 continuous NCM preview, USB descriptor
  diagnostics and board-specific USB-NCM fallback with forced interface claims.
  Camera admission uses monotonic time; paused or replaced sessions discard
  in-flight results. Repeated commands after a valid release appear in history.
- Retained face/ear/background filtering before classification and overlays,
  Open Palm/Stop Inverted surface correction and Like/Thumb Down direction
  correction. The same detector/runtime serves phone and NCM sources.
- Included current Android source and a rebuilt ARM64 diagnostic release APK,
  matching runtime assets and manifests, exact source ONNX/configuration,
  integration guides and extracted-payload verification.
- FP32 remains the only integration default. The refreshed INT8 candidate
  passes offline conversion gates but remains blocked pending its own geometry,
  controller and mobile qualification.

`HOST_CHECKS.json` records fresh checks and source hashes.
`static_gesture_runtime/validation/latency_comparison.json` compares old/current
classifier invocation on the same host. It excludes detection, camera transport,
rendering and action confirmation and does not establish mobile latency.

The APK uses release Dart code with Android shrinking disabled and the Android
debug signing key for testing. iOS build/signing and physical iPhone/NCM tests
remain app-team acceptance steps. The native filter update is retained as a
reference; the complete integration path in this delivery is Flutter/LiteRT.
