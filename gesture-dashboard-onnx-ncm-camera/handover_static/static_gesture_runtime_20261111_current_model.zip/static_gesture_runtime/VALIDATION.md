# Current model validation, updated 11 November 2026

The false-hand update passes 52 runtime tests and 2 tester tests, including the
real face model's tensor/blank-image contract and 42 Python/Dart policy cases.
The native Kotlin filter and detector wrapper compile against MediaPipe 1.1.1
and pass the same 42 Python/Kotlin cases. Swift policy fixtures and a Mac runner
are supplied; iOS compilation and physical-device tests remain pending.
The Dart face decoder also matches the expected face regions on 12 saved
face/ear images (box IoU above 0.5) and reports no face on 24 saved background
images, using actual TFLite model outputs. This checks face preprocessing and
decoding, rather than mobile hand-detection or action accuracy.
The detector checks above describe the 31 October revision. Fresh host results
for the current runtime/tester are recorded in the complete delivery's
`HOST_CHECKS.json`; retain physical-device acceptance as a separate step.

The original deployed ONNX SHA-256 is
`bb1df78e02ec0aaf8d55fe9edb78503d2ca5b473245a15c0cc3f7c37c91de2b2`.
The new default FP32 TFLite SHA-256 is
`47746adac0d301f5d2ea4b7b5620cc185e4b1a248170f882c7836849c321d4f1`.
The conversion copies the learned weights; no retraining was performed.

| Check | Result | Scope |
|---|---|---|
| FP32 model conversion | Passed | All 9,031 validation and 9,042 test rows retain the same top label and scalar gate decision |
| Maximum FP32 probability error | 0.00000172854 | Compared with current ONNX on both caches |
| Maximum FP32 known-mass error | 0.00000146032 | Compared with current ONNX on both caches |
| Default model size | 78,960 bytes | TFLite builtin operations; no Flex dependency |
| Canonical feature/geometry regressions | 1,142/1,142 passed | Features, adjusted rows, final decisions and geometry support; includes 98.3% incorrect thumb-label cases |
| Canonical known-mass qualifications | 5,710/5,710 passed | Includes strict low-mass recoveries and rejection |
| Additional held-out cache geometry | 400/400 passed | All twelve commands and hard negatives; forced classifier labels isolate geometry |
| Native Flutter LiteRT inference | 26 current reference cases supplied | Actual persistent interpreter/isolate check is rerun in current `HOST_CHECKS.json` |
| Flutter tests and Dart analysis | Current results in `HOST_CHECKS.json` | Includes palm/back surfaces, controller, parser, coordinates, TCP lifecycle, latest-frame handling and preview |
| Detector provenance | Hash checked | 40 source/config/asset files copied from supplied dynamic archive |

The complete test suite exercised real LiteRT inference and a local TCP/JLIP
server. The hand detector was injected in lifecycle tests. OpenCV's native
Windows build hook was temporarily skipped because these tests do not execute
OpenCV. Normal native builds are enabled in the delivered pubspec. See
`HOST_TESTING.md` for the reproducible host-test configuration.

The `fix1` host run used one Flutter test file per invocation to keep memory
within the Windows host's available commit limit. All runtime/tester test files
passed. Surface tests run detector-adapter output through geometry using
explicit physical Left/Right fixtures. The extra geometry handedness swap was
removed, and mirrored detector input is normalized to unmirrored image/world X.
The shared parity runner now supplies each Python fixture's physical hand
directly. Thumb regressions reconstruct the reported side view; screenshots
were not replayed through MediaPipe. See `validation/thumb_surface_checks.json`.

## INT8 candidate

The candidate is 23,240 bytes and uses calibrated INT8 dense layers, with FP32
normalization and the open-set probability tail. It is not fully integer.

With the current learned weights, the INT8 conversion passes the existing
offline gate: validation top-label agreement is 99.5903%; test agreement is
99.6461%. This does not promote INT8 into the app. Its manifest separately
records `conversion_passed: true` and `qualification.passed: false` because
precision-specific geometry/controller and target-device acceptance are pending.
The runtime continues to reject INT8 loading. FP32 retains the current ONNX
predictions exactly at the scalar decision level and remains the default.

## Boundaries of the evidence

The scalar gate comparison uses confidence 0.75, known mass 0.70, margin 0.10
and disabled Dorsal rejection. It does not include pose geometry, the new
controller timing, tracking or action dispatch. Those are tested separately.
The converter now reads these gates from the current runtime JSON and records
that file's hash, rather than qualifying new weights with historical thresholds.

The current horizontal-pointing, side-view Like, and strict Fist thumb-radius
and PIP-overshoot rules have been ported to Dart. Canonical and refreshed cache
geometry checks pass all rows and geometry-support decisions.

## Speed comparison

`validation/latency_comparison.json` records 4,000 timed warm CPU invokes for
each FP32 model on identical inputs, alternating the previous/current model
order. Both medians are 0.0031 ms; P95 is 0.0054 ms previous and 0.0052 ms
current. Both models are 78,960 bytes. These are same-host native invocation
measurements, not camera or phone latency. The 100 ms admission interval,
single pending-frame slot, persistent interpreter, immediate strong-result
confirmation and ordinary two-of-three consensus remain unchanged. No fixed
action cooldown has been introduced. Strict geometry recovery still has holds.

The NCM runtime now reports each completed frame's `receiveToResultMs`, including
pending wait, so the tester can display current local pipeline latency. The
board and host clocks remain unsynchronized, so this excludes capture-to-receipt
time and cannot establish zero latency.

The canonical geometry fixture contains synthetic and reconstructed landmark
cases, not new camera images. The additional cache cases have no original
source dimensions or world depth, so they use declared square-frame dimensions
and offline Fist geometry. Separate world-coordinate rotation and live-depth
requirements are covered by adapter/geometry tests.

Calibration used 1,391 stratified rows from the existing replay cache. Validation
and untouched test rows were not used to compute quantization ranges. Detailed
file hashes and numerical results are in `validation/conversion_report.json`.

Host inference timing in that report is only native invocation time. It does
not measure iPhone performance, JPEG transport, detection, display rendering or
capture-to-command latency, and must not be used to claim a mobile speedup.

iOS compilation, actual GPU/CPU detector selection, NCM accessory routing,
lighting/distance accuracy, sustained FPS, heat/power and false commands per
minute must be measured in the consuming app on physical iPhones. The package
includes the example and aggregate timing output needed to run those checks
without sharing private application data.
