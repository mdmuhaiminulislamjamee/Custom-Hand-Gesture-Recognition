# Native transport host checks

check_native_usb_ncm.py and android/host_tests/NativeNcmMain.kt are the Windows/JVM transport regression harness. The script expects the prepared Gradle cache and JDK/Android SDK paths used by the build host; adapt those paths on another workstation. Flutter builds/tests do not invoke this script. Run the root verify_handover.py for portable payload/APK verification.
