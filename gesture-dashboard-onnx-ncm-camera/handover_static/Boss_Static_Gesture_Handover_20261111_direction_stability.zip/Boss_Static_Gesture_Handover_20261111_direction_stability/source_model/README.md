# Production classifier source snapshot

These exact ONNX/configuration/metadata files identify the source used for the FP32 TFLite conversion. The Flutter runtime loads the converted model under static_gesture_runtime/flutter/assets/models/.

The source JSON includes desktop controller settings. For Flutter timing, retain the supplied Dart controller: immediate strong predictions, two of three ordinary confirmation and no fixed action cooldown. Use the source JSON's current scalar gates (.75 confidence, .10 margin, .70 known mass) with the matching feature and geometry code.
